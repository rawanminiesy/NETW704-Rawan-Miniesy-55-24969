package com.example.netw704.fragments

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.netw704.R
import com.example.netw704.adapters.productAdapter
import com.example.netw704.medRequests
import com.example.netw704.meds
import com.example.netw704.models.CartItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class medicineFragmentpatient : Fragment() {

    private lateinit var database: DatabaseReference
    private lateinit var medRequestsReference: DatabaseReference
    // UI elements
    private lateinit var cartReference: DatabaseReference
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: productAdapter
    private val medsList = mutableListOf<meds>()
    private var namePatientSelected: String? = null // Holds the patient's name
    private val cartItemsList = mutableListOf<CartItem>()
    private var reviewedDatabase: String = ""
    private lateinit var medimage:ImageView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_medicinepatient, container, false)

        // Initialize RecyclerView with a grid layout
        recyclerView = view.findViewById(R.id.medsRecyclerView)
        recyclerView.layoutManager = GridLayoutManager(context, 2)

        database = FirebaseDatabase.getInstance().getReference("products")
        medRequestsReference = FirebaseDatabase.getInstance().getReference("medRequests")
        cartReference = FirebaseDatabase.getInstance().getReference("cart")


        // Get patient's email from activity intent and retrieve user info
        val email = activity?.intent?.getStringExtra("email").toString()
        if (email.isNotEmpty()) {
            retrieveUserInfo(email) { name ->
                namePatientSelected = name
            }
        } else {
            Toast.makeText(requireContext(), "Email not found.", Toast.LENGTH_SHORT).show()
        }

        adapter = productAdapter(medsList) { selectedMedicine ->
            showPopup(selectedMedicine, namePatientSelected ?: "")
        }
        recyclerView.adapter = adapter

        fetchMedicinesFromFirebase()

        return view
    }


    // Fetch medicines from the Firebase database
    private fun fetchMedicinesFromFirebase() {
        database.get().addOnSuccessListener { snapshot ->
            medsList.clear()
            snapshot.children.forEach { productSnapshot ->
                val name = productSnapshot.child("name").value?.toString()
                val price = productSnapshot.child("price").value.toString().toFloatOrNull() ?: 0.0f
                val img = productSnapshot.child("img").value?.toString() ?: ""
                val quantity = productSnapshot.child("quantity").value?.toString()?.toIntOrNull() ?: 0

                if (name != null && img != null) {
                    val medication = meds(
                        img = img,
                        name = name,
                        price = price,
                        quantity = quantity
                    )
                    medsList.add(medication)
                }
            }
            adapter.notifyDataSetChanged()
        }.addOnFailureListener { error ->
            Toast.makeText(context, "Error in database: ${error.message}", Toast.LENGTH_SHORT).show()
        }
    }
    // Show popup dialog for medicine selection

    @SuppressLint("MissingInflatedId")
    private fun showPopup(medicineSelected: meds, namePatientSelected: String) {
        medRequestsReference.get().addOnSuccessListener { snapshot ->
            var status = "No requests"
            var requestedQuantity = 0 // This will track the quantity for this session
            var isApproved = false

            snapshot.children.forEach { productSnapshot ->
                val nameMedicineDatabase = productSnapshot.child("name").value?.toString()
                val approvedDatabase = productSnapshot.child("approved").value?.toString()
                val nameOfPatientDatabase = productSnapshot.child("nameOfPatient").value?.toString()
                reviewedDatabase = productSnapshot.child("reviewed").value?.toString().toString()

                if (namePatientSelected == nameOfPatientDatabase && nameMedicineDatabase == medicineSelected.name) {
                    status = when {
                        approvedDatabase == "true" && reviewedDatabase == "true" -> {
                            isApproved = true
                            "Approved"
                        }
                        approvedDatabase == "false" && reviewedDatabase == "true" -> "Rejected"
                        reviewedDatabase == "false" -> "Pending"
                        else -> "No requests"
                    }

                    requestedQuantity = productSnapshot.child("quantityRequested").value?.toString()?.toIntOrNull() ?: 0
                }
            }

            // Inflate and setup the popup dialog
            val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_medicine_popup, null)
            val dialogBuilder = AlertDialog.Builder(requireContext())
            dialogBuilder.setView(dialogView)
            medimage = dialogView.findViewById(R.id.medimage)

            val statusTextView = dialogView.findViewById<TextView>(R.id.statusTextView)
            val actionButton = dialogView.findViewById<Button>(R.id.addToCartButton)
            val okButton = dialogView.findViewById<Button>(R.id.okButton)
            val increaseb = dialogView.findViewById<Button>(R.id.increaseButton)
            val deccreaseb = dialogView.findViewById<Button>(R.id.decreaseButton)
            var quantityToAdd = 0

            statusTextView.text = "Name: ${medicineSelected.name}\nPrice: ${medicineSelected.price}\nStatus: $status"

            val dialog = dialogBuilder.create()
            if (medicineSelected.img.isNotEmpty()) {
                Glide.with(this)
                    .load(medicineSelected.img)
                    .into(medimage)
            } else {
                medimage.setImageResource(R.drawable.ic_android_white_24dp)
            }

            increaseb.setOnClickListener {
                quantityToAdd++

                if(isApproved){
                    statusTextView.text =
                        "Name: ${medicineSelected.name}\nPrice: ${medicineSelected.price * quantityToAdd}\nStatus: Approved\nRequested Quantity: $quantityToAdd"

                }else if(status == "Pending"){
                    statusTextView.text =
                        "Name: ${medicineSelected.name}\nPrice: ${medicineSelected.price * quantityToAdd}\nStatus: Pending\nRequested Quantity: $quantityToAdd"

                }else if(status =="Declined"){
                    statusTextView.text =
                        "Name: ${medicineSelected.name}\nPrice: ${medicineSelected.price * quantityToAdd}\nStatus: Declined\nRequested Quantity: $quantityToAdd"

                }else{
                    statusTextView.text =
                        "Name: ${medicineSelected.name}\nPrice: ${medicineSelected.price * quantityToAdd}\nStatus: No Request\nRequested Quantity: $quantityToAdd"

                }
            }

            deccreaseb.setOnClickListener {
                quantityToAdd--

                if(isApproved){
                    statusTextView.text =
                        "Name: ${medicineSelected.name}\nPrice: ${medicineSelected.price * quantityToAdd}\nStatus: Approved\nRequested Quantity: $quantityToAdd"

                }else if(status == "Pending"){
                    statusTextView.text =
                        "Name: ${medicineSelected.name}\nPrice: ${medicineSelected.price * quantityToAdd}\nStatus: Pending\nRequested Quantity: $quantityToAdd"

                }else if(status =="Declined"){
                    statusTextView.text =
                        "Name: ${medicineSelected.name}\nPrice: ${medicineSelected.price * quantityToAdd}\nStatus: Declined\nRequested Quantity: $quantityToAdd"

                }else{
                    statusTextView.text =
                        "Name: ${medicineSelected.name}\nPrice: ${medicineSelected.price * quantityToAdd}\nStatus: No Request\nRequested Quantity: $quantityToAdd"

                }

            }

            if (isApproved) {
                actionButton.text = "Add to Cart"
                actionButton.setOnClickListener {
                    if (medicineSelected.quantity >= quantityToAdd) {
                        val updatedQuantityProduct = medicineSelected.quantity - quantityToAdd
                        updateMedicineQuantityInDatabase(medicineSelected, updatedQuantityProduct)
                        addToCart(medicineSelected, quantityToAdd)
                        //statusTextView.text =
                        //    "Price: ${medicineSelected.price * quantityToAdd}\nStatus: Approved\nRequested Quantity: $quantityToAdd"
                        Toast.makeText(
                            context,
                            "Added ${medicineSelected.name} to cart.",
                            Toast.LENGTH_SHORT
                        ).show()
                    } else {
                        Toast.makeText(context, "Not enough stock available.", Toast.LENGTH_SHORT).show()
                    }
                }
            } else if (status == "Pending") {
                actionButton.isEnabled = false
            } else {
                actionButton.text = "Ask for Approval"
                actionButton.setOnClickListener {
                    saveRequestToDatabase(
                        medicineSelected.name,
                        namePatientSelected,
                        false,
                        false,
                        quantityToAdd,
                        medicineSelected.img
                    )
                    Toast.makeText(
                        context,
                        "Requested approval for ${medicineSelected.name}.",
                        Toast.LENGTH_SHORT
                    ).show()
                    actionButton.isEnabled = false
                    dialog.dismiss()
                }
            }

            okButton.setOnClickListener { dialog.dismiss() }
            dialog.show()
        }.addOnFailureListener { error ->
            Toast.makeText(context, "Error in database: ${error.message}", Toast.LENGTH_SHORT).show()
        }
    }


    private fun updateMedicineQuantityInDatabase(medicine: meds, updatedQuantity: Int) {
        database.orderByChild("name").equalTo(medicine.name)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        for (medicineSnapshot in snapshot.children) {
                            medicineSnapshot.ref.child("quantity").setValue(updatedQuantity)
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        medicine.quantity = updatedQuantity
                                        Toast.makeText(context, "Medicine quantity updated.", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Error updating quantity: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                        }
                    } else {
                        Toast.makeText(context, "Medicine not found in the database.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(context, "Database error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun saveRequestToDatabase(
        name: String,
        nameofPatient: String,
        reviewed: Boolean,
        approved: Boolean,
        requestedQuantity: Int,
        img: String
    ) {
        val userId = medRequestsReference.push().key
        if (userId != null) {
            val medRequest = medRequests(name, nameofPatient, reviewed, approved, img, requestedQuantity)
            medRequestsReference.child(userId).setValue(medRequest)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(requireContext(), "Request saved successfully!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(requireContext(), "Error: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    private fun addToCart(medicine: meds, requestedQuantity: Int) {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        cartReference.child(userId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                var itemExists = false
                for (cartSnapshot in snapshot.children) {
                    val cartItem = cartSnapshot.getValue(CartItem::class.java)
                    if (cartItem?.medicineName == medicine.name) {
                        val totalQuantity = cartItem.requestedQuantity + requestedQuantity
                        val updatedCartItem = mapOf(
                            "medicineName" to medicine.name,
                            "requestedQuantity" to totalQuantity,
                            "price" to medicine.price,
                            "medicineimage" to medicine.img,
                            "patientName" to namePatientSelected
                        )
                        cartSnapshot.ref.updateChildren(updatedCartItem)
                        itemExists = true
                        break
                    }
                }
                if (!itemExists) {
                    val newCartItem = CartItem(medicine.name, requestedQuantity, medicine.price, namePatientSelected.toString(), medicine.img)
                    cartReference.child(userId).push().setValue(newCartItem)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun retrieveUserInfo(email: String, onResult: (String) -> Unit) {
        val usersRef = FirebaseDatabase.getInstance().getReference("Users")
        usersRef.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (userSnapshot in snapshot.children) {
                        val name = userSnapshot.child("name").value?.toString() ?: "Unknown"
                        onResult(name)
                    }
                } else {
                    Toast.makeText(context, "No user found with this email.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(context, "Database error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
