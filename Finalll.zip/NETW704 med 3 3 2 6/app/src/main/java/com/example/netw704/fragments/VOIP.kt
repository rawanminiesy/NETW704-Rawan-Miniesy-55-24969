package com.example.call

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.net.wifi.WifiManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.netw704.R
import java.net.ServerSocket
import java.net.Socket
import android.media.audiofx.NoiseSuppressor
import android.media.audiofx.AcousticEchoCanceler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress

class VOIP : Fragment() {

    private val PORT = 50020 // Port for communication
    @Volatile private var isRunning = false // Tracks if the VOIP connection is active
    private var serverSocket: ServerSocket? = null
    private var clientSocket: Socket? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_v_o_i_p, container, false)

        // Request necessary permissions
        requestPermissions()

        // UI element references
        val serverButton: Button = view.findViewById(R.id.btnStartServer)
        val clientButton: Button = view.findViewById(R.id.btnConnectClient)
        val ipEditText: EditText = view.findViewById(R.id.EDIT)
        val endCallButton: Button = view.findViewById(R.id.btnendcall)
        val showIpButton: Button = view.findViewById(R.id.btnShowIp)
        val ipTextView: TextView = view.findViewById(R.id.tvIpAddress)

        // Reset button states initially
        resetButtons()

        // Set up button click listeners
        serverButton.setOnClickListener {
            resetButtons(enableEndCall = true)
            Thread { startServer() }.start()
        }

        clientButton.setOnClickListener {
            val ipAddress = ipEditText.text.toString()
            if (ipAddress.isNotEmpty()) {
                resetButtons(enableEndCall = true)
                pingIP(ipAddress) { isReachable ->
                    if (isReachable) {
                        showToast("Ping successful!")
                    } else {
                        showToast("Ping failed!")
                    }
                }
                Thread { startClient(ipAddress) }.start()
            } else {
                showToast("Please enter a valid IP address.")
            }
        }

        showIpButton.setOnClickListener {
            val ipAddress = getLocalIpAddress()
            ipTextView.text = "Your IP: $ipAddress"
            showToast("Your IP Address: $ipAddress")
        }

        endCallButton.setOnClickListener {
            endCall()
        }

        return view
    }

    // Request permissions at runtime
    private fun requestPermissions() {
        val permissions = arrayOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.INTERNET,
            Manifest.permission.ACCESS_WIFI_STATE
        )
        if (permissions.any { ContextCompat.checkSelfPermission(requireContext(), it) != PackageManager.PERMISSION_GRANTED }) {
            ActivityCompat.requestPermissions(requireActivity(), permissions, 0)
        }
    }

    // Reset the state of UI buttons
    private fun resetButtons(enableServer: Boolean = true, enableClient: Boolean = true, enableEndCall: Boolean = false) {
        activity?.runOnUiThread {
            view?.findViewById<Button>(R.id.btnStartServer)?.isEnabled = enableServer
            view?.findViewById<Button>(R.id.btnConnectClient)?.isEnabled = enableClient
            view?.findViewById<Button>(R.id.btnendcall)?.isEnabled = enableEndCall
        }
    }

    // Start the server and wait for a client to connect
    private fun startServer() {
        try {
            serverSocket = ServerSocket(PORT)
            showToast("Server started. Waiting for client...")
            clientSocket = serverSocket?.accept() // Wait for client connection
            clientSocket?.getOutputStream()?.write("CTRL:CONNECTED".toByteArray())
            Log.d("DEBUG", "Sent control message: CTRL:CONNECTED")
            handleCommunication(clientSocket!!)
        } catch (e: Exception) {
            Log.e("VOIP", "Error starting server", e)
            resetButtons()
            showToast("Error starting server. Check logs.")
        }
    }

    // Connect to a server as a client
    private fun startClient(ipAddress: String) {
        try {
            clientSocket = Socket(ipAddress, PORT)
            val confirmationBuffer = ByteArray(1024)
            val confirmationRead = clientSocket?.getInputStream()?.read(confirmationBuffer)
            val confirmationMessage = confirmationRead?.let { String(confirmationBuffer, 0, it).trim() }

            if (confirmationMessage == "CTRL:CONNECTED") {
                showToast("Connected to server at $ipAddress")
                handleCommunication(clientSocket!!)
            } else {
                showToast("Failed to connect: Server not ready")
                closeConnections()
            }
        } catch (e: Exception) {
            Log.e("VOIP", "Connection failed", e)
            resetButtons()
            showToast("Error connecting to server.")
        }
    }

    // Handle bi-directional communication between server and client
    private fun handleCommunication(socket: Socket) {
        val bufferSize = AudioRecord.getMinBufferSize(44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val audioRecord = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 44100, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, bufferSize)
        val audioTrack = AudioTrack.Builder()
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(44100)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(bufferSize)
            .build()

        // Enable Noise Suppression and Echo Cancellation
        enableAudioEffects(audioRecord.audioSessionId)

        audioRecord.startRecording()
        audioTrack.play()

        val bufferedOutput = socket.getOutputStream().buffered()
        val bufferedInput = socket.getInputStream().buffered()
        val buffer = ByteArray(bufferSize)

        isRunning = true
        updateUIBasedOnState()

        // Thread for sending audio
        Thread {
            try {
                while (isRunning) {
                    val read = audioRecord.read(buffer, 0, buffer.size)
                    if (read > 0 && !socket.isClosed) {
                        try {
                            bufferedOutput.write(buffer, 0, read)
                            bufferedOutput.flush()
                        } catch (e: Exception) {
                            Log.e("VOIP", "Error sending audio", e)
                            break
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("VOIP", "Error in sending thread", e)
            } finally {
                audioRecord.release()
                closeConnections()
                showToast("Connections closed.")
            }
        }.start()

        // Thread for receiving audio
        Thread {
            try {
                while (isRunning) {
                    val read = bufferedInput.read(buffer)
                    if (read > 0) {
                        audioTrack.write(buffer, 0, read)
                    }
                }
            } catch (e: Exception) {
                Log.e("VOIP", "Error receiving audio", e)
            } finally {
                audioTrack.release()
                closeConnections()
                showToast("Connections closed.")
            }
        }.start()
    }


    // End the call and notify the other party
    private fun endCall() {
        Thread {
            try {
                clientSocket?.getOutputStream()?.apply {
                    if (!clientSocket!!.isClosed) {
                        write("CTRL:CALL_ENDED".toByteArray())
                        Log.d("DEBUG", "Sent control message: CTRL:CALL_ENDED")
                        flush()
                    }
                }
            } catch (e: Exception) {
                Log.e("VOIP", "Error sending call end signal", e)
            } finally {
                isRunning = false
                updateUIBasedOnState()
                closeConnections()
                showToast("Connections closed.")
            }
        }.start()
    }

    // Close connections and release resources
    private fun closeConnections() {
        try {
            isRunning = false
            clientSocket?.close()
            serverSocket?.close()
        } catch (e: Exception) {
            Log.e("VOIP", "Error closing connections", e)
        } finally {
            updateUIBasedOnState()
            //showToast("Connections closed.")
        }
    }

    // Update the UI buttons based on the connection state
    private fun updateUIBasedOnState() {
        resetButtons(
            enableServer = !isRunning,
            enableClient = !isRunning,
            enableEndCall = isRunning
        )
    }

    // Get the local IP address of the device
    private fun getLocalIpAddress(): String? {
        val wifiManager = requireContext().applicationContext.getSystemService(WifiManager::class.java)
        val ipAddress = wifiManager?.connectionInfo?.ipAddress
        return if (ipAddress != null) {
            String.format(
                "%d.%d.%d.%d",
                (ipAddress and 0xff),
                (ipAddress shr 8 and 0xff),
                (ipAddress shr 16 and 0xff),
                (ipAddress shr 24 and 0xff)
            )
        } else null
    }

    // Show a Toast message
    private fun showToast(message: String) {
        activity?.runOnUiThread {
            Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
        }
    }

    // Enable Noise Suppression and Acoustic Echo Cancellation
    private fun enableAudioEffects(audioSessionId: Int) {
        // Enable Noise Suppressor
        if (NoiseSuppressor.isAvailable()) {
            val noiseSuppressor = NoiseSuppressor.create(audioSessionId)
            if (noiseSuppressor != null) {
                Log.d("VOIP", "Noise Suppressor enabled.")
            } else {
                Log.w("VOIP", "Failed to enable Noise Suppressor.")
            }
        } else {
            Log.w("VOIP", "Noise Suppressor is not available on this device.")
        }

        // Enable Acoustic Echo Canceler
        if (AcousticEchoCanceler.isAvailable()) {
            val echoCanceler = AcousticEchoCanceler.create(audioSessionId)
            if (echoCanceler != null) {
                echoCanceler.enabled = true
                Log.d("VOIP", "Acoustic Echo Canceler enabled.")
            } else {
                Log.w("VOIP", "Failed to enable Acoustic Echo Canceler.")
            }
        } else {
            Log.w("VOIP", "Acoustic Echo Canceler is not available on this device.")
        }

    }
    fun     pingIP(ipAddress: String, onResult: (Boolean) -> Unit) {
        // Launch a coroutine to run the network operation
        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Resolve the IP address and ping it
                val address = InetAddress.getByName(ipAddress)
                val reachable = address.isReachable(5000) // Timeout = 3000 ms

                // Return result to the main thread
                withContext(Dispatchers.Main) {
                    if (reachable == true) {
                    Log.w("PING","SUCCESSFUL PING") }
                    else{
                        Log.w("PING"," PING FAILED")}
                    onResult(reachable)
                }
            } catch (e: Exception) {

               Log.w("pingfailed",e.printStackTrace().toString())
                // Return false in case of an error
                withContext(Dispatchers.Main) {
                    onResult(false)
                }
            }
        }
    }

}