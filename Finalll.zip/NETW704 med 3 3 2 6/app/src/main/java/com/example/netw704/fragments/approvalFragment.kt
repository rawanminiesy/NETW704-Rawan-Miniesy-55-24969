package com.example.netw704.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.netw704.R
import com.example.netw704.medRequests
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

// Fragment to manage and display medicine requests for approval or decline
class approvalFragment : Fragment() {

    // Firebase database reference to the "medRequests" node
    private lateinit var medRequestsReference: DatabaseReference

    // Layout container to dynamically add request views
    private lateinit var requestsContainer: LinearLayout

    // Listener to track changes in the database
    private lateinit var valueEventListener: ValueEventListener

    // Inflate the fragment's layout and initialize UI elements
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_approval, container, false)

        // Initialize the container layout where requests will be displayed
        requestsContainer = view.findViewById(R.id.requestsContainer)

        // Get a reference to the "medRequests" node in Firebase
        medRequestsReference = FirebaseDatabase.getInstance().getReference("medRequests")

        // Fetch and display unreviewed requests from the database
        fetchUnreviewedRequests()

        return view
    }

    // Fetch requests from Firebase that are not yet reviewed
    private fun fetchUnreviewedRequests() {
        // Set up a listener for real-time data changes
        valueEventListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Ensure the fragment is attached before updating the UI
                if (!isAdded) return

                // Clear the existing views to avoid duplication
                requestsContainer.removeAllViews()

                // Iterate over each request in the database
                for (requestSnapshot in snapshot.children) {
                    val request = requestSnapshot.getValue(medRequests::class.java)
                    // Add unreviewed requests to the UI
                    if (request != null && !request.reviewed) {
                        addRequestToView(request, requestSnapshot.key)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Display an error message if the data fetch is canceled
                if (isAdded) {
                    Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
        // Attach the listener to the Firebase reference
        medRequestsReference.addValueEventListener(valueEventListener)
    }

    // Remove the listener when the view is destroyed to avoid memory leaks
    override fun onDestroyView() {
        super.onDestroyView()
        medRequestsReference.removeEventListener(valueEventListener)
    }

    // Dynamically add a request to the UI for review
    private fun addRequestToView(request: medRequests, requestId: String?) {
        // Inflate the custom request item layout
        val requestView = LayoutInflater.from(requireContext()).inflate(R.layout.request_item, requestsContainer, false)

        // Initialize UI elements in the request item
        val requestNameTextView: TextView = requestView.findViewById(R.id.requestName)
        val patientNameTextView: TextView = requestView.findViewById(R.id.patientName)
        val quanTextView: TextView = requestView.findViewById(R.id.quan)
        val approveButton: Button = requestView.findViewById(R.id.approveButton)
        val declineButton: Button = requestView.findViewById(R.id.declineButton)
        val medImageView: ImageView = requestView.findViewById(R.id.medImageView)

        // Populate the UI elements with request data
        requestNameTextView.text = "Medicine: ${request.name}"
        patientNameTextView.text = "Patient: ${request.nameOfPatient}"
        quanTextView.text = "Quantity: ${request.quantity.toString()}"

        // Load the medicine image if available, otherwise use a placeholder
        if (!request.img.isNullOrEmpty()) {
            Glide.with(requestView.context)
                .load(request.img)
                .into(medImageView)
        } else {
            medImageView.setImageResource(R.drawable.ic_android_white_24dp)
        }

        // Handle approve button click
        approveButton.setOnClickListener {
            if (requestId != null) {
                approveRequest(requestId)
            } else {
                Toast.makeText(requireContext(), "Error: Request ID is missing.", Toast.LENGTH_SHORT).show()
            }
        }

        // Handle decline button click
        declineButton.setOnClickListener {
            if (requestId != null) {
                declineRequest(requestId)
            } else {
                Toast.makeText(requireContext(), "Error: Request ID is missing.", Toast.LENGTH_SHORT).show()
            }
        }

        // Add the request view to the container
        requestsContainer.addView(requestView)
    }

    // Approve a request by updating its status in Firebase
    private fun approveRequest(requestId: String) {
        medRequestsReference.child(requestId).child("approved").setValue(true)
        medRequestsReference.child(requestId).child("reviewed").setValue(true)
        Toast.makeText(requireContext(), "Request approved!", Toast.LENGTH_SHORT).show()
    }

    // Decline a request by updating its status in Firebase
    private fun declineRequest(requestId: String) {
        medRequestsReference.child(requestId).child("approved").setValue(false)
        medRequestsReference.child(requestId).child("reviewed").setValue(true)
        Toast.makeText(requireContext(), "Request declined.", Toast.LENGTH_SHORT).show()
    }
}
