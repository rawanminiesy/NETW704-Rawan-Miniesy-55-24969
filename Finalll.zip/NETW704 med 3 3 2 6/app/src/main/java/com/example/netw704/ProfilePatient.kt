package com.example.netw704

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.example.netw704.fragments.adapters.RetrofitClient
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.conn.util.PublicSuffixMatcherLoader.load
import com.google.firebase.database.*
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProfilePatient : AppCompatActivity() {

    private lateinit var database: DatabaseReference
    private lateinit var auth: FirebaseAuth

    private lateinit var nameTextView: TextView
    private lateinit var emailTextView: TextView
    private lateinit var ageTextView: TextView
    private lateinit var genderTextView: TextView
    private lateinit var typeTextView: TextView
    private lateinit var saveButton: Button
    private lateinit var  profilepic: ImageView
    private lateinit var  editimage: Button
    private lateinit var profileurl:String
    private lateinit var currentPhotoPath: String
    private val REQUEST_CAMERA = 101
    private val REQUEST_GALLERY = 102
    private val PERMISSION_REQUEST_CODE = 100
    private var imageUri: Uri? = null
    private lateinit var progressBar: ProgressBar

    // UI components for password change
    private lateinit var currentPasswordEditText: EditText
    private lateinit var newPasswordEditText: EditText
    private lateinit var updatePasswordButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile2)

        // Set up the toolbar as the action bar and enable the back button
        supportActionBar?.apply {
            title = "Patient Profile"
            setDisplayHomeAsUpEnabled(true)  // Enable the back button
        }

        // Initialize Firebase components
        auth = FirebaseAuth.getInstance()
        database = FirebaseDatabase.getInstance().getReference("Users")  // This is the root node for users

        // Initialize TextViews
        nameTextView = findViewById(R.id.nameTextView)
        emailTextView = findViewById(R.id.emailTextView)
        ageTextView = findViewById(R.id.ageTextView)
        genderTextView = findViewById(R.id.genderTextView)
        typeTextView = findViewById(R.id.typeTextView)
        saveButton = findViewById(R.id.saveButton)
        profilepic = findViewById(R.id.profilepic)
        editimage = findViewById(R.id.editimage)

        // Initialize UI components for password change
        currentPasswordEditText = findViewById(R.id.currentPasswordEditText)
        newPasswordEditText = findViewById(R.id.newPasswordEditText)
        updatePasswordButton = findViewById(R.id.updatePasswordButton)
        progressBar = findViewById(R.id.progressBar)
        profileurl = ""

        emailTextView.isEnabled = false
        //ageTextView.isEnabled = false
        genderTextView.isEnabled = false
        typeTextView.isEnabled = false

        // Fetch user data from Firebase
        val userEmail = auth.currentUser?.email
        if (userEmail != null) {
            retrieveUserInfo(userEmail) { name, age, gender, type, image ->
                // Set the values retrieved from Firebase
                nameTextView.text = name
                emailTextView.text = userEmail
                ageTextView.text = age
                genderTextView.text = gender
                typeTextView.text = type
                profileurl = image


            }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }


        val currentUser = auth.currentUser
        if (currentUser != null) {
            val userId = currentUser.uid  // UID of the logged-in user
            fetchUserInfo(userId) { name, email, age, gender, type, image->
                nameTextView.setText(name)
                emailTextView.text = email
                ageTextView.setText(age)
                genderTextView.setText(gender)
                typeTextView.text = type
                profileurl
            }
        } else {
            Toast.makeText(this, "User not logged in.", Toast.LENGTH_SHORT).show()
        }
        if (profileurl.isNotEmpty()) {
            Glide.with(this)
                .load(profileurl)
                .circleCrop()
                .into(profilepic)
        } else {
            Log.e("ProfilePatient", "No profile URL available.")
        }

        editimage.setOnClickListener{
            Log.d("ProfilePatient", "editimage button clicked")
            chooseImageSource()
        }
        // Save updated profile info
        saveButton.setOnClickListener {
            val updatedName = nameTextView.text.toString().trim()
            val updatedAge = ageTextView.text.toString().trim()

            if (updatedName.isEmpty() || updatedAge.isEmpty()) {
                Toast.makeText(this, "Please fill in all fields.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val currentUser = auth.currentUser
            if (currentUser != null) {
                val userEmail = currentUser.email.toString()
                if (imageUri != null) {
                    progressBar.visibility = View.VISIBLE
                    lifecycleScope.launch {
                        val imageFile = convertUriToFile(imageUri!!)
                        val imageUrl = uploadImageToImgur(imageFile)
                        progressBar.visibility = View.GONE
                        if (imageUrl != null) {
                            updateUserInfo(userEmail, updatedName, updatedAge, imageUrl)
                            Toast.makeText(this@ProfilePatient, "Profile updated Successfully ", Toast.LENGTH_SHORT).show()


                        } else {
                            Toast.makeText(this@ProfilePatient, "Image upload failed", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                else{
                    updateUserInfo(userEmail, updatedName, updatedAge, profileurl)
                    Toast.makeText(this@ProfilePatient, "Profile updated Successfully ", Toast.LENGTH_SHORT).show()

                }
            }

            else {
                Toast.makeText(this, "User not logged in.", Toast.LENGTH_SHORT).show()
            }
        }


        // Update password
        updatePasswordButton.setOnClickListener {
            val currentPassword = currentPasswordEditText.text.toString().trim()
            val newPassword = newPasswordEditText.text.toString().trim()

            if (currentPassword.isEmpty() || newPassword.isEmpty()) {
                Toast.makeText(this, "Both fields are required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (newPassword.length < 6) {
                Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val user = auth.currentUser
            if (user != null) {
                val credential = EmailAuthProvider.getCredential(user.email!!, currentPassword)

                user.reauthenticate(credential).addOnCompleteListener { authTask ->
                    if (authTask.isSuccessful) {
                        // Re-authentication successful, now update password
                        user.updatePassword(newPassword).addOnCompleteListener { passwordTask ->
                            if (passwordTask.isSuccessful) {
                                Toast.makeText(this, "Password updated successfully", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this, "Password update failed: ${passwordTask.exception?.message}", Toast.LENGTH_LONG).show()
                            }
                        }
                    } else {
                        Toast.makeText(this, "Re-authentication failed: ${authTask.exception?.message}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    private fun updateUserInfo(userEmail: String, updatedName: String, updatedAge: String, newimageurl:String) {
        database.orderByChild("email").equalTo(userEmail)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {

                    if (snapshot.exists()) {
                        for (userSnapshot in snapshot.children) {
                            userSnapshot.ref.child("name").setValue(updatedName)
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        Log.d("ProfilePatient", "Updated name successfully")

                                    } else {
                                        Log.e("ProfilePatient", "Failed to update name: ${task.exception?.message}")
                                    }
                                }

                            userSnapshot.ref.child("age").setValue(updatedAge)
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        Log.d("ProfilePatient", "Updated age successfully")

                                    } else {
                                        Log.e("ProfilePatient", "Failed to update age: ${task.exception?.message}")
                                    }
                                }

                            userSnapshot.ref.child("image").setValue(newimageurl)
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        Log.d("ProfilePatient", "Updated image successfully")

                                    } else {
                                        Log.e("ProfilePatient", "Failed to update image: ${task.exception?.message}")
                                    }
                                }
                        }

                    } else {
                        Toast.makeText(this@ProfilePatient, "User not found in the database.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@ProfilePatient, "Database error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }


    private fun fetchUserInfo(userId: String, onResult: (String, String, String, String, String, String) -> Unit) {
        database.child(userId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val name = snapshot.child("name").value?.toString() ?: "Unknown"
                    val email = snapshot.child("email").value?.toString() ?: "N/A"
                    val age = snapshot.child("age").value?.toString() ?: "N/A"
                    val gender = snapshot.child("gender").value?.toString() ?: "N/A"
                    val type = snapshot.child("type").value?.toString() ?: "N/A"
                    val image = snapshot.child("image").value?.toString() ?: "N/A"

                    onResult(name, email, age, gender, type, image)
                } else {
                    //"ana el shelto 3shan 3amel wag3 dma8 wel code sha8al 3adi"
                // Toast.makeText(this@ProfilePatient, "User data not found.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ProfilePatient, "Database error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
        })
    }
    // Handle back button click
    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()  // Navigate back to the previous activity
        return true
    }



    // Function to retrieve user info by email from Firebase
    private fun retrieveUserInfo(email: String, onResult: (String, String, String, String, String) -> Unit) {
        val usersRef = FirebaseDatabase.getInstance().getReference("Users")
        usersRef.orderByChild("email").equalTo(email).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    for (userSnapshot in snapshot.children) {
                        val name = userSnapshot.child("name").value?.toString() ?: "Unknown"
                        val age = userSnapshot.child("age").value?.toString() ?: "N/A"
                        val gender = userSnapshot.child("gender").value?.toString() ?: "N/A"
                        val type = userSnapshot.child("type").value?.toString() ?: "N/A"
                        val image = userSnapshot.child("image").value?.toString() ?: "N/A"



                        onResult(name, age, gender, type, image)  // Pass the values to the onResult callback
                        Log.d("ProfilePatient", "Profile URL retrieved: $profileurl")

                        if (profileurl.isNotEmpty()) {
                            Glide.with(this@ProfilePatient)
                                .load(profileurl)
                                .circleCrop()
                                .into(profilepic)
                        } else {
                            Glide.with(this@ProfilePatient)
                                .load(R.drawable.img_22) // Fallback
                                .circleCrop()
                                .into(profilepic)
                            Log.e("ProfilePatient", "No profile URL available, using default image.")
                        }

                    }
                } else {
                    Toast.makeText(this@ProfilePatient, "No user found with this email.", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ProfilePatient, "Database error: ${error.message}", Toast.LENGTH_SHORT).show()
            }
            })
        }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(
                this, Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                this, Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this, arrayOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ), PERMISSION_REQUEST_CODE
            )
        }
    }

    private fun chooseImageSource() {
//        if (!isAdded) {
//            Log.e("MedicineDetailDialogFragment", "Fragment not attached to context. Skipping.")
//            return
//        }

        val options = arrayOf("Take Photo", "Choose from Gallery")
        this?.let { ctx ->
            val builder = android.app.AlertDialog.Builder(ctx)
            builder.setTitle("Choose Image Source")
            builder.setItems(options) { _, which ->
                when (which) {
                    0 -> openCamera()
                    1 -> openGallery()
                }
            }
            builder.show()
        } ?: run {
            Log.e("MedicineDetailDialogFragment", "Context is null. Cannot show dialog.")
        }
    }


    private fun openCamera() {
        val photoFile: File? = try {
            createImageFile() // Create temporary file
        } catch (ex: IOException) {
            Log.e("Camera", "Error creating file", ex)
            null
        }

        photoFile?.also {
            val photoUri: Uri = FileProvider.getUriForFile(
                this,
                "com.example.netw704.fileprovider", // Use your package name
                it
            )
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, photoUri) // Pass Uri to save the image
            }
            startActivityForResult(cameraIntent, REQUEST_CAMERA)
        }
    }

    private fun openGallery() {
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent, REQUEST_GALLERY)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CAMERA -> {
                    imageUri = Uri.fromFile(File(currentPhotoPath)) // Get Uri of captured image
                    profilepic.setImageURI(imageUri) // Display the image
                }
                REQUEST_GALLERY -> {
                    imageUri = data?.data
                    profilepic.setImageURI(imageUri)
                }
            }
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timestamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File = this.getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timestamp}_", ".jpg", storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }

    private fun convertUriToFile(uri: Uri): File {
        val inputStream = this.contentResolver.openInputStream(uri)
        val tempFile = File(this.cacheDir, "temp_image.jpg")
        inputStream?.use { input ->
            tempFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return tempFile
    }

    private suspend fun uploadImageToImgur(imageFile: File): String? {
        val authHeader = "Client-ID 0465aaf2c983df2"
        val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), imageFile)
        val body = MultipartBody.Part.createFormData("image", imageFile.name, requestFile)

        try {
            val response = RetrofitClient.instance.uploadImage(authHeader, body)
            if (response.isSuccessful) {
                return response.body()?.data?.link
            } else {
                Log.e("Imgur", "Upload failed: ${response.message()}")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("Imgur", "Upload exception: ${e.message}")
        }
        return null
    }

}