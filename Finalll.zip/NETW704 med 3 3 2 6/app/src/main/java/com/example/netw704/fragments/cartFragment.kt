package com.example.netw704.fragments

import CartAdapter
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.netw704.R
import com.example.netw704.models.CartItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

/**
 * Fragment to display and manage the user's cart.
 * Allows users to view cart items, clear the cart, and purchase items.
 */
class cartFragment : Fragment() {

    // RecyclerView and its adapter for displaying cart items
    private lateinit var cartRecyclerView: RecyclerView
    private lateinit var cartAdapter: CartAdapter

    // Firebase database references
    private lateinit var cartReference: DatabaseReference
    private lateinit var productReference: DatabaseReference

    // List to store the cart items fetched from Firebase
    private val cartItemsList = mutableListOf<CartItem>()

    // Variable to calculate and display the total price of items in the cart
    private var totalPrice: Double = 0.0

    /**
     * Creates and initializes the fragment's view.
     */
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_cart, container, false)

        // Initialize RecyclerView with a vertical layout manager
        cartRecyclerView = view.findViewById(R.id.cartRecyclerView)
        cartRecyclerView.layoutManager = LinearLayoutManager(context)

        // Initialize adapter for the RecyclerView
        cartAdapter = CartAdapter(cartItemsList)
        cartRecyclerView.adapter = cartAdapter

        // Reference to the "cart" node in Firebase
        cartReference = FirebaseDatabase.getInstance().getReference("cart")
        productReference = FirebaseDatabase.getInstance().getReference("products")

        // Button to clear the cart
        val clearCartButton = view.findViewById<Button>(R.id.clearCart)
        clearCartButton.setOnClickListener {
            clearCart() // Clear all items from the cart
        }

        // Button to purchase all items in the cart
        val buyButton = view.findViewById<Button>(R.id.buyCart)
        buyButton.setOnClickListener {
            buyAllItemsFromCart() // Purchase all cart items
        }

        // Fetch and display cart items
        fetchCartItems()

        return view
    }

    /**
     * Clears the cart and restores item quantities in the product database.
     */
    private fun clearCart() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val cartRef = cartReference.child(userId)

        // Loop through each cart item and update the product stock
        for (cartItem in cartItemsList) {
            productReference.orderByChild("name").equalTo(cartItem.medicineName)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        if (snapshot.exists()) {
                            for (productSnapshot in snapshot.children) {
                                val currentQuantity =
                                    productSnapshot.child("quantity").getValue(Int::class.java) ?: 0
                                val updatedQuantity = currentQuantity + cartItem.requestedQuantity
                                productSnapshot.ref.child("quantity").setValue(updatedQuantity)
                            }
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT)
                            .show()
                    }
                })
        }

        // Clear all items from the user's cart
        cartRef.removeValue().addOnSuccessListener {
            Toast.makeText(context, "Cart Cleared", Toast.LENGTH_SHORT).show()
        }.addOnFailureListener {
            Toast.makeText(context, "Failed to Clear: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Purchases all items in the cart and removes them from the database.
     */
    private fun buyAllItemsFromCart() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val cartRef = cartReference.child(userId)

        // Remove all items from the cart
        cartRef.removeValue().addOnSuccessListener {
            Toast.makeText(context, "Cart bought", Toast.LENGTH_SHORT).show()
        }.addOnFailureListener {
            Toast.makeText(context, "Failed to buy: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Fetches cart items from Firebase and updates the RecyclerView.
     */
    private fun fetchCartItems() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        cartReference.child(userId).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Clear existing cart items and reset the total price
                cartItemsList.clear()
                totalPrice = 0.0

                // Add each cart item to the list and calculate the total price
                for (cartSnapshot in snapshot.children) {
                    val cartItem = cartSnapshot.getValue(CartItem::class.java)
                    cartItem?.let {
                        cartItemsList.add(it)
                        totalPrice += it.price * it.requestedQuantity
                    }
                }

                // Notify the adapter of data changes and update the total price in the UI
                cartAdapter.notifyDataSetChanged()
                val totalPriceTextView = view?.findViewById<TextView>(R.id.totalPriceTextView)
                totalPriceTextView?.text = "Total: $$totalPrice"
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }
}
