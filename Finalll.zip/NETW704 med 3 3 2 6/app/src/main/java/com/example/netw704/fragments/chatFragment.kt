package com.example.netw704.fragments

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import com.example.netw704.R
import com.github.furkankaplan.fkblurview.FKBlurView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

/**
 * Fragment to manage and display consultations.
 * Allows users to view consultation messages, reply to them, and mark them as reviewed.
 */
class chatFragment : Fragment() {

    // References to Firebase database nodes
    private lateinit var consultationsReference: DatabaseReference
    private lateinit var usersReference: DatabaseReference

    // Layout container for dynamically displaying consultations
    private lateinit var consultationsContainer: LinearLayout

    // Variable to store the doctor's name
    private var doctorName: String? = null

    @SuppressLint("MissingInflatedId")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        // Inflate the fragment layout
        val view = inflater.inflate(R.layout.fragment_chat, container, false)

        // Initialize Firebase database references
        consultationsReference = FirebaseDatabase.getInstance().getReference("Consultations")
        usersReference = FirebaseDatabase.getInstance().getReference("Users")

        // Find the container for consultations in the layout
        consultationsContainer = view.findViewById(R.id.consultationsContainer)

        // Retrieve email passed to the activity and fetch corresponding user info
        val email = activity?.intent?.getStringExtra("email")
        if (email != null) {
            retrieveUserInfo(email) { name ->
                doctorName = name // Set the doctor's name
            }
        } else {
            Toast.makeText(requireContext(), "Email not found.", Toast.LENGTH_SHORT).show()
        }

        // Fetch and display consultations from Firebase
        fetchConsultations()

        return view
    }

    /**
     * Fetches consultation messages from Firebase and adds them to the view.
     */
    private fun fetchConsultations() {
        consultationsReference.orderByChild("reviewed").equalTo(false)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    // Clear previous views before adding new ones
                    consultationsContainer.removeAllViews()

                    // Loop through consultations marked as not reviewed
                    for (consultationSnapshot in snapshot.children) {
                        val consultation = consultationSnapshot.value as? Map<String, Any>
                        if (consultation != null) {
                            addConsultationToView(
                                consultation["id"] as String,
                                consultation["senderName"] as String,
                                consultation["message"] as String
                            )
                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    /**
     * Dynamically adds a consultation message to the container.
     */
    private fun addConsultationToView(consultationId: String, senderName: String, message: String) {
        // Inflate the consultation item layout
        val consultationView = LayoutInflater.from(requireContext())
            .inflate(R.layout.consultation_item, consultationsContainer, false)

        // Set the sender name and message in the view
        val senderNameTextView: TextView = consultationView.findViewById(R.id.senderName)
        val messageTextView: TextView = consultationView.findViewById(R.id.message)
        val replyButton: Button = consultationView.findViewById(R.id.replyButton)

        senderNameTextView.text = "From: $senderName"
        messageTextView.text = message

        // Set the reply button click listener
        replyButton.setOnClickListener {
            showReplyDialog(consultationId, senderName, message)
        }

        // Add the consultation view to the container
        consultationsContainer.addView(consultationView)
    }

    /**
     * Displays a dialog for the doctor to reply to a consultation message.
     */
    @SuppressLint("MissingInflatedId")
    private fun showReplyDialog(consultationId: String, senderName: String, message: String) {
        // Inflate the reply dialog layout
        val dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_reply, null)

        val replyInput: EditText = dialogView.findViewById(R.id.replyInput)

        // Create and display the alert dialog
        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Reply to $senderName")
            .setMessage(message)
            .setView(dialogView)
            .setPositiveButton("Send") { _, _ ->
                val reply = replyInput.text.toString().trim()
                if (reply.isNotEmpty()) {
                    sendReply(consultationId, reply)
                } else {
                    Toast.makeText(requireContext(), "Reply cannot be empty", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()

        dialog.show()
    }

    /**
     * Sends the reply to Firebase and marks the consultation as reviewed.
     */
    private fun sendReply(consultationId: String, reply: String) {
        val updates = mapOf(
            "reviewed" to true, // Mark consultation as reviewed
            "doctorName" to doctorName, // Add doctor's name
            "reply" to reply // Save the reply
        )

        consultationsReference.child(consultationId).updateChildren(updates)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(requireContext(), "Reply sent!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(requireContext(), "Failed to send reply", Toast.LENGTH_SHORT).show()
                }
            }
    }

    /**
     * Retrieves user information (e.g., name) based on their email.
     */
    private fun retrieveUserInfo(email: String, callback: (String) -> Unit) {
        usersReference.orderByChild("email").equalTo(email)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Loop through users to find a matching email
                        for (userSnapshot in snapshot.children) {
                            val name = userSnapshot.child("name").getValue(String::class.java)
                            if (!name.isNullOrEmpty()) {
                                callback(name) // Pass the name to the callback
                                return
                            }
                        }
                        Toast.makeText(requireContext(), "Name not found for the user.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(requireContext(), "User not found.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }
}
