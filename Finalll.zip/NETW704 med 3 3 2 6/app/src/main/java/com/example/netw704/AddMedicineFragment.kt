package com.example.netw704.fragments

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.example.netw704.R
import com.example.netw704.fragments.adapters.RetrofitClient
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.launch
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class AddMedicineFragment : DialogFragment() {

    // Constants for permissions and activity results
    private val REQUEST_CAMERA = 101
    private val REQUEST_GALLERY = 102
    private val PERMISSION_REQUEST_CODE = 100

    private lateinit var selectedImageView: ImageView
    private var imageUri: Uri? = null
    private lateinit var currentPhotoPath: String
    private var onDismissListener: (() -> Unit)? = null
    private lateinit var progressBar: ProgressBar  // Declare the ProgressBar

    // Listener to handle fragment dismissal
    fun setOnDismissListener(listener: () -> Unit) {
        onDismissListener = listener
    }

    override fun onDismiss(dialog: DialogInterface) {
        super.onDismiss(dialog)
        onDismissListener?.invoke()
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_add_medicine, container, false)

        val medNameEditText: EditText = view.findViewById(R.id.medNameEditText)
        val medPriceEditText: EditText = view.findViewById(R.id.medPriceEditText)
        val medQuantityEditText: EditText = view.findViewById(R.id.medQuantityEditText)
        val addMedicineButton: Button = view.findViewById(R.id.addMedicineButton)
        val uploadImageButton: Button = view.findViewById(R.id.uploadimageButton)
        val exitButton: Button = view.findViewById((R.id.exitButton))
        selectedImageView = view.findViewById(R.id.selectedImageView)
        progressBar = view.findViewById(R.id.progressBar)  // Initialize the ProgressBar
        checkPermissions()

        exitButton.setOnClickListener{
            dismiss()
        }
        // Handle the upload image button click
        uploadImageButton.setOnClickListener {
            chooseImageSource()
        }

        // Handle the add medicine button click
        addMedicineButton.setOnClickListener {
            val name = medNameEditText.text.toString()
            val price = medPriceEditText.text.toString().toFloatOrNull()
            val quantity = medQuantityEditText.text.toString().toIntOrNull()

            if (name.isEmpty() || price == null || quantity == null) {
                Toast.makeText(context, "Please fill all fields", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (imageUri != null) {
                // Show progress bar
                progressBar.visibility = View.VISIBLE
                // Launch a coroutine to upload the image and save medicine details

                lifecycleScope.launch {
                    val imageFile = convertUriToFile(imageUri!!)
                    val imageUrl = uploadImageToImgur(imageFile)
                    // Hide progress bar after upload is done
                    progressBar.visibility = View.GONE
                    if (imageUrl != null) {
                        saveMedicineToFirebase(name, price, quantity, imageUrl)
                    } else {
                        Toast.makeText(context, "Image upload failed", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(context, "Please select an image", Toast.LENGTH_SHORT).show()
            }
        }

        return view
    }
    // Check and request necessary permissions
    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.CAMERA
            ) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.WRITE_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(
                requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                requireActivity(), arrayOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ), PERMISSION_REQUEST_CODE
            )
        }
    }
    // Allow the user to choose image source (camera or gallery)
    fun chooseImageSource() {
        if (!isAdded) {
            Log.e("MedicineDetailDialogFragment", "Fragment not attached to context. Skipping.")
            return
        }

        val options = arrayOf("Take Photo", "Choose from Gallery")
        context?.let { ctx ->
            val builder = android.app.AlertDialog.Builder(ctx)
            builder.setTitle("Choose Image Source")
            builder.setItems(options) { _, which ->
                when (which) {
                    0 -> openCamera()
                    1 -> openGallery()
                }
            }
            builder.show()
        } ?: run {
            Log.e("MedicineDetailDialogFragment", "Context is null. Cannot show dialog.")
        }
    }


    private fun openCamera() {
        val photoFile: File? = try {
            createImageFile() // Create temporary file
        } catch (ex: IOException) {
            Log.e("Camera", "Error creating file", ex)
            null
        }

        photoFile?.also {
            val photoUri: Uri = FileProvider.getUriForFile(
                requireContext(),
                "com.example.netw704.fileprovider", // Use your package name
                it
            )
            val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_OUTPUT, photoUri) // Pass Uri to save the image
            }
            startActivityForResult(cameraIntent, REQUEST_CAMERA)
        }
    }

    private fun openGallery() {
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent, REQUEST_GALLERY)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK) {
            when (requestCode) {
                REQUEST_CAMERA -> {
                    imageUri = Uri.fromFile(File(currentPhotoPath)) // Get Uri of captured image
                    selectedImageView.setImageURI(imageUri) // Display the image
                }
                REQUEST_GALLERY -> {
                    imageUri = data?.data
                    selectedImageView.setImageURI(imageUri)
                }
            }
        }
    }

    @Throws(IOException::class)
    private fun createImageFile(): File {
        val timestamp: String = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val storageDir: File = requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES)!!
        return File.createTempFile(
            "JPEG_${timestamp}_", ".jpg", storageDir
        ).apply {
            currentPhotoPath = absolutePath
        }
    }

    private fun convertUriToFile(uri: Uri): File {
        val inputStream = requireContext().contentResolver.openInputStream(uri)
        val tempFile = File(requireContext().cacheDir, "temp_image.jpg")
        inputStream?.use { input ->
            tempFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
        return tempFile
    }

    private suspend fun uploadImageToImgur(imageFile: File): String? {
        val authHeader = "Client-ID 0465aaf2c983df2"
        val requestFile = RequestBody.create("image/*".toMediaTypeOrNull(), imageFile)
        val body = MultipartBody.Part.createFormData("image", imageFile.name, requestFile)

        try {
            val response = RetrofitClient.instance.uploadImage(authHeader, body)
            if (response.isSuccessful) {
                return response.body()?.data?.link
            } else {
                Log.e("Imgur", "Upload failed: ${response.message()}")
            }
        } catch (e: Exception) {
            e.printStackTrace()
            Log.e("Imgur", "Upload exception: ${e.message}")
        }
        return null
    }

    private fun saveMedicineToFirebase(name: String, price: Float, quantity: Int, imageUrl: String) {
        val database = FirebaseDatabase.getInstance().reference
        val productId = database.child("products").push().key

        if (productId != null) {
            val product = mapOf(
                "img" to imageUrl,
                "name" to name,
                "price" to price,
                "quantity" to quantity
            )

            database.child("products").child(productId).setValue(product)
                .addOnSuccessListener {
                    Toast.makeText(context, "Medicine added successfully", Toast.LENGTH_SHORT).show()
                    dismiss()
                }
                .addOnFailureListener { error ->
                    Toast.makeText(context, "Error adding medicine: ${error.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }
}
