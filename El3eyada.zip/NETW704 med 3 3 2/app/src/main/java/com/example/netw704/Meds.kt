package com.example.netw704

import androidx.compose.ui.geometry.times
import androidx.compose.ui.unit.times
import kotlin.time.times

data class meds(
    var name: String = "",
    var price: Float,
    var img: String = "",
    var quantity: Int  // Add quantity property
)