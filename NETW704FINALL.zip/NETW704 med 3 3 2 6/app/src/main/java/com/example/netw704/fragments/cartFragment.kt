package com.example.netw704.fragments

import CartAdapter
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.netw704.R
import com.example.netw704.models.CartItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class cartFragment : Fragment() {

    private lateinit var cartRecyclerView: RecyclerView
    private lateinit var cartAdapter: CartAdapter
    private lateinit var cartReference: DatabaseReference
    private val cartItemsList = mutableListOf<CartItem>()
    private var totalPrice: Double = 0.0  // Variable to store the total price
    private lateinit var productReference: DatabaseReference


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_cart, container, false)
        cartRecyclerView = view.findViewById(R.id.cartRecyclerView)
        cartRecyclerView.layoutManager = LinearLayoutManager(context)

        // Initialize the adapter
        cartAdapter = CartAdapter(cartItemsList)
        cartRecyclerView.adapter = cartAdapter

        // Reference to Firebase
        cartReference = FirebaseDatabase.getInstance().getReference("cart")

        productReference = FirebaseDatabase.getInstance().getReference("products")

        val clearCartButton = view.findViewById<Button>(R.id.clearCart)
        clearCartButton.setOnClickListener {
            clearCart()
        }


        // Fetch and display cart items
        fetchCartItems()

        val buyButton = view.findViewById<Button>(R.id.buyCart)
        buyButton.setOnClickListener {
            buyAllItemsFromCart()
        }

        return view
    }

    private fun clearCart() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val cartRef = FirebaseDatabase.getInstance().getReference("cart").child(userId)
        val productsRef = FirebaseDatabase.getInstance().getReference("products")

        for(cartItem in cartItemsList){
            productsRef.child(cartItem.medicineName).get().addOnSuccessListener {
                //val currentQuantity = it.child("quantity").getValue(Int::class.java) ?: 0
               // val updatedQuantity = currentQuantity + cartItem.requestedQuantity
                productsRef.orderByChild("name").equalTo(cartItem.medicineName)
                    .addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(snapshot: DataSnapshot) {
                            if (snapshot.exists()) {
                                for (productSnapshot in snapshot.children) {
                                    // Get the current quantity and increment it by the requested quantity
                                    val currentQuantity =
                                        productSnapshot.child("quantity").getValue(Int::class.java) ?: 0
                                    val updatedQuantity = currentQuantity + cartItem.requestedQuantity
                                    productSnapshot.ref.child("quantity").setValue(updatedQuantity)
                                        .addOnCompleteListener { task ->
                                            if (task.isSuccessful) {
                                                Toast.makeText(
                                                    context,
                                                    "Item Quantity decreased by 1 in product.",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            } else {
                                                Toast.makeText(
                                                    context,
                                                    "Error updating quantity: ${task.exception?.message}",
                                                    Toast.LENGTH_SHORT
                                                ).show()
                                            }
                                        }
                                }
                            } else {
                                Toast.makeText(
                                    context,
                                    "Medicine not found in the database.",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT)
                                .show()
                        }
                    })

            }

        }
        cartRef.removeValue().addOnSuccessListener {
            Toast.makeText(context, "Cart Cleared", Toast.LENGTH_SHORT).show()
        }.addOnFailureListener {
            Toast.makeText(context, "Failed to Clear: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun buyAllItemsFromCart() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val cartRef = FirebaseDatabase.getInstance().getReference("cart").child(userId)

        for(cartItem in cartItemsList){
            cartRef.child(cartItem.medicineName).removeValue()
        }
        cartRef.removeValue().addOnSuccessListener {
            Toast.makeText(context, "Cart bought", Toast.LENGTH_SHORT).show()
        }.addOnFailureListener {
            Toast.makeText(context, "Failed to buy: ${it.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun fetchCartItems() {
        val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return  // Ensure user is logged in
        cartReference.child(userId).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                cartItemsList.clear()
                totalPrice = 0.0  // Reset total price before recalculating

                for (cartSnapshot in snapshot.children) {
                    val cartItem = cartSnapshot.getValue(CartItem::class.java)
                    cartItem?.let {
                        cartItemsList.add(it)
                        // Add the item's total price (price * quantity) to the totalPrice variable
                        totalPrice += it.price * it.requestedQuantity
                    }
                }

                cartAdapter.notifyDataSetChanged()

                // Update the total price in the UI
                val totalPriceTextView = view?.findViewById<TextView>(R.id.totalPriceTextView)
                totalPriceTextView?.text = "Total: $$totalPrice"
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }

}

