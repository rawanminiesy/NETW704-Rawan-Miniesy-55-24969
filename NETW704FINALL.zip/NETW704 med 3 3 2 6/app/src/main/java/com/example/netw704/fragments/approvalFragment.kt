package com.example.netw704.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.bumptech.glide.Glide
import com.example.netw704.R
import com.example.netw704.medRequests
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class approvalFragment : Fragment() {

    private lateinit var medRequestsReference: DatabaseReference
    private lateinit var requestsContainer: LinearLayout
    private lateinit var valueEventListener: ValueEventListener

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_approval, container, false)

        // Initialize the container layout
        requestsContainer = view.findViewById(R.id.requestsContainer)

        // Reference to Firebase
        medRequestsReference = FirebaseDatabase.getInstance().getReference("medRequests")

        // Fetch and display unreviewed requests
        fetchUnreviewedRequests()

        return view
    }

    private fun fetchUnreviewedRequests() {
        valueEventListener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!isAdded) return // Ensure Fragment is attached

                // Clear the container before adding new views
                requestsContainer.removeAllViews()

                for (requestSnapshot in snapshot.children) {
                    val request = requestSnapshot.getValue(medRequests::class.java)
                    if (request != null && !request.reviewed) {
                        addRequestToView(request, requestSnapshot.key)
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                if (isAdded) {
                    Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
        medRequestsReference.addValueEventListener(valueEventListener)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        medRequestsReference.removeEventListener(valueEventListener)
    }

    private fun addRequestToView(request: medRequests, requestId: String?) {
        val requestView = LayoutInflater.from(requireContext()).inflate(R.layout.request_item, requestsContainer, false)

        // Set request details
        val requestNameTextView: TextView = requestView.findViewById(R.id.requestName)
        val patientNameTextView: TextView = requestView.findViewById(R.id.patientName)
        val quanTextView: TextView = requestView.findViewById(R.id.quan)
        val approveButton: Button = requestView.findViewById(R.id.approveButton)
        val declineButton: Button = requestView.findViewById(R.id.declineButton)
        val medImageView: ImageView = requestView.findViewById(R.id.medImageView)

        requestNameTextView.text ="Medicine: ${request.name}"
        patientNameTextView.text = "Patient: ${request.nameOfPatient}"
        quanTextView.text="Quantity: ${request.quantity.toString()}"

        if (!request.img.isNullOrEmpty()) {
            Glide.with(requestView.context)
                .load(request.img)
                .into(medImageView)
        } else {
            medImageView.setImageResource(R.drawable.ic_android_white_24dp)
        }

        // Handle button actions
        approveButton.setOnClickListener {
            if (requestId != null) {
                approveRequest(requestId)
            } else {
                Toast.makeText(requireContext(), "Error: Request ID is missing.", Toast.LENGTH_SHORT).show()
            }
        }

        declineButton.setOnClickListener {
            if (requestId != null) {
                declineRequest(requestId)
            } else {
                Toast.makeText(requireContext(), "Error: Request ID is missing.", Toast.LENGTH_SHORT).show()
            }
        }

        requestsContainer.addView(requestView)
    }

    private fun approveRequest(requestId: String) {
        medRequestsReference.child(requestId).child("approved").setValue(true)
        medRequestsReference.child(requestId).child("reviewed").setValue(true)
        Toast.makeText(requireContext(), "Request approved!", Toast.LENGTH_SHORT).show()
    }

    private fun declineRequest(requestId: String) {
        medRequestsReference.child(requestId).child("approved").setValue(false)
        medRequestsReference.child(requestId).child("reviewed").setValue(true)
        Toast.makeText(requireContext(), "Request declined.", Toast.LENGTH_SHORT).show()
    }
}
