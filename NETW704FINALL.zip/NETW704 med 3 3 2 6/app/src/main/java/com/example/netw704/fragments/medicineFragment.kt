package com.example.netw704.fragments

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.netw704.MedicineDetailDialogFragment
import com.example.netw704.R
import com.example.netw704.adapters.productAdapter
import com.example.netw704.meds
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


class medicineFragment : Fragment() {

    lateinit var database: DatabaseReference
    lateinit var recyclerView: RecyclerView
    lateinit var adapter: productAdapter
    val medsList = mutableListOf<meds>()  // List to store medicines
    var flag: Boolean = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_medicine, container, false)

        // Initialize RecyclerView with GridLayoutManager
        recyclerView = view.findViewById(R.id.medsRecyclerView)
        recyclerView.layoutManager = GridLayoutManager(context, 2)

        // Initialize Firebase Database reference to "products"
        database = FirebaseDatabase.getInstance().reference

        // Initialize the adapter
        //adapter = productAdapter(medsList)
        recyclerView = view.findViewById(R.id.medsRecyclerView)
        adapter = productAdapter(medsList) { selectedMedicine ->
            val dialog = MedicineDetailDialogFragment.newInstance(selectedMedicine, true)
            dialog.show(parentFragmentManager, "MedicineDetailDialog")
        }
        recyclerView.adapter = adapter

        val refreshButton: Button = view.findViewById(R.id.refresh)
        refreshButton.setOnClickListener {

            fetchMedicinesFromFirebase()

        }

        // Handle Add Medicine button
        val addMedicineButton: Button = view.findViewById(R.id.mapp)
        addMedicineButton.setOnClickListener {
            Log.d("medicineFragment", "Add Medicine button clicked")

            // Show AddMedicineDialogFragment as a popup
            val addMedicineDialog = AddMedicineFragment()
            val supportFragmentManager = requireActivity().supportFragmentManager
//            addMedicineDialog.setOnDismissListener {
//                fetchMedicinesWithDelay() // Fetch medicines after delay
//            }
            addMedicineDialog.show(supportFragmentManager, "AddMedicineDialogFragment")
        }

        // Fetch data from Firebase initially
        fetchMedicinesFromFirebase()

        return view
    }




     fun fetchMedicinesFromFirebase() {
        database.child("products").get().addOnSuccessListener { snapshot ->
            medsList.clear() // Clear the existing list to avoid duplicates

            // Iterate through each child in the "products" node
            snapshot.children.forEach { productSnapshot ->
                val name = productSnapshot.child("name").value.toString()
                val price = productSnapshot.child("price").value.toString().toFloatOrNull() ?: 0.0f
                Log.d("PRICE", "${price}")
                val img = productSnapshot.child("img").value.toString()

                // Safely convert the quantity to an integer, defaulting to 0 if conversion fails
                val quantity = productSnapshot.child("quantity").value.toString().toIntOrNull() ?: 0

                val medication = meds(
                    name = name,
                    price = price,
                    img = img,
                    quantity = quantity // Ensure quantity is not null
                )
                medsList.add(medication)
            }

            // Notify the adapter that the data has changed
            adapter.notifyDataSetChanged()
            Log.d("medicineFragment", "Medicines fetched from Firebase")

        }.addOnFailureListener { error ->
            Toast.makeText(context, "Error in database: ${error.message}", Toast.LENGTH_SHORT).show()
            Log.e("medicineFragment", "Error fetching medicines: ${error.message}")
        }
    }

    private fun fetchMedicinesWithDelay() {
        // Add a short delay before fetching medicines again
        val delayMillis = 1000L // 1 second
        Handler(Looper.getMainLooper()).postDelayed({
            fetchMedicinesFromFirebase()
            Log.d("medicineFragment", "Medicines fetched after delay")
        }, delayMillis)
    }



}
