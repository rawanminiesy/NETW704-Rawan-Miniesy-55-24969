package com.example.netw704

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.viewpager.widget.ViewPager
import com.example.call.VOIP
import com.example.netw704.fragments.adapters.ViewPagerAdapter
import com.example.netw704.fragments.approvalFragment
import com.example.netw704.fragments.chatFragment
import com.example.netw704.fragments.medicineFragment
import com.google.android.material.navigation.NavigationView
import com.google.android.material.tabs.TabLayout

class Doctor : AppCompatActivity() {

    private lateinit var viewPager: ViewPager
    private lateinit var tabs: TabLayout
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var toolbar: Toolbar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor)

        // Initialize DrawerLayout, NavigationView, and Toolbar
        drawerLayout = findViewById(R.id.drawer_layout)
        val navigationView: NavigationView = findViewById(R.id.nav_view)
        toolbar = findViewById(R.id.toolbar)

        // Set the Toolbar as the app bar
        setSupportActionBar(toolbar)

        // Set up the ActionBarDrawerToggle for the hamburger menu
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        // Handle navigation item clicks
        navigationView.setNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_logout -> {
                    // Perform logout action
                    val intent = Intent(this, Login::class.java)
                    startActivity(intent)
                    finish() // Close Doctor activity
                    true
                }
                R.id.nav_about -> {
                    // Navigate to Profile activity
                    val intent = Intent(this, Profile::class.java)
                    startActivity(intent)
                    true
                }
                else -> false
            }
        }

        // Initialize ViewPager and TabLayout
        viewPager = findViewById(R.id.viewPager)
        tabs = findViewById(R.id.tabs)

        // Set up the ViewPager and Tabs
        setUpTabs()
    }

    private fun setUpTabs() {
        val adapter = ViewPagerAdapter(supportFragmentManager)
        // Add fragments to the ViewPager
        adapter.addFragment(chatFragment(), "Chat")
        adapter.addFragment(medicineFragment(), "Medicines")
        adapter.addFragment(approvalFragment(), "Approval")
        adapter.addFragment(VOIP(), "VOIP")


        // Set the adapter for ViewPager
        viewPager.adapter = adapter
        // Set up TabLayout with ViewPager
        tabs.setupWithViewPager(viewPager)

        // Set icons for the tabs
        tabs.getTabAt(0)?.setIcon(R.drawable.baseline_chat_24)
        tabs.getTabAt(1)?.setIcon(R.drawable.baseline_add_shopping_car_24)
        tabs.getTabAt(2)?.setIcon(R.drawable.baseline_check_box_24)
        tabs.getTabAt(3)?.setIcon(R.drawable.baseline_call_24)

    }
}
