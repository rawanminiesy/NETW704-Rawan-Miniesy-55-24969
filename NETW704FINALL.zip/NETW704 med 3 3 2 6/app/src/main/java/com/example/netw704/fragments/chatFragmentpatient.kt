package com.example.netw704.fragments

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.netw704.R
import com.example.netw704.adapters.productAdapter
import com.example.netw704.meds
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class chatFragmentpatient : Fragment() {

    private lateinit var consultationsReference: DatabaseReference
    private lateinit var usersReference: DatabaseReference
    private lateinit var sendMessageButton: Button
    private lateinit var clearHistoryButton: Button
    private lateinit var viewHistoryButton: Button
    private lateinit var messageInput: EditText
    private lateinit var historyContainer: LinearLayout


    private var patientName: String? = null // Holds the patient's name

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        val view = inflater.inflate(R.layout.fragment_chatpatient, container, false)

        consultationsReference = FirebaseDatabase.getInstance().getReference("Consultations")
        usersReference = FirebaseDatabase.getInstance().getReference("Users")

        sendMessageButton = view.findViewById(R.id.sendMessageButton)
        viewHistoryButton = view.findViewById(R.id.viewHistoryButton)
        messageInput = view.findViewById(R.id.messageInput)
        historyContainer = view.findViewById(R.id.historyContainer)

        clearHistoryButton = view.findViewById(R.id.clearHistoryButton)

        val email = activity?.intent?.getStringExtra("email")
        if (email != null) {
            retrieveUserInfo(email) { name ->
                patientName = name // Set the patient's name after retrieval
            }
        } else {
            Toast.makeText(requireContext(), "Email not found.", Toast.LENGTH_SHORT).show()
        }



        sendMessageButton.setOnClickListener {
            val message = messageInput.text.toString().trim()
            if (message.isNotEmpty()) {
                if (patientName != null) {
                    sendMessage(message)
                } else {
                    Toast.makeText(requireContext(), "Patient name not retrieved yet.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(requireContext(), "Please enter a message", Toast.LENGTH_SHORT).show()
            }
        }

        viewHistoryButton.setOnClickListener {
            if (patientName != null) {
                //to add
                fetchConsultationHistory()
            } else {
                Toast.makeText(requireContext(), "Patient name not retrieved yet.", Toast.LENGTH_SHORT).show()
            }
        }

        clearHistoryButton.setOnClickListener {
            // Show a confirmation dialog
            AlertDialog.Builder(requireContext())
                .setTitle("Clear History")
                .setMessage("Are you sure you want to clear your consultation history?")
                .setPositiveButton("Yes") { dialog, _ ->
                    clearConsultationHistory() // Call the method to clear history
                    dialog.dismiss() // Close the dialog
                }
                .setNegativeButton("No") { dialog, _ ->
                    dialog.dismiss() // Close the dialog without any action
                }
                .create()
                .show()
        }



        return view
    }

    private fun sendMessage(message: String) {
        val consultationId = consultationsReference.push().key
        if (consultationId != null && patientName != null) {
            val consultation = mapOf(
                "id" to consultationId,
                "senderName" to patientName,
                "message" to message,
                "reviewed" to false,
                "doctorName" to null,
                "reply" to null
            )

            consultationsReference.child(consultationId).setValue(consultation)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(requireContext(), "Message sent!", Toast.LENGTH_SHORT).show()
                        messageInput.text.clear()
                    } else {
                        Toast.makeText(requireContext(), "Failed to send message", Toast.LENGTH_SHORT).show()
                    }
                }
        } else {
            Toast.makeText(requireContext(), "Failed to send message. Missing patient name.", Toast.LENGTH_SHORT).show()
        }
    }



    private fun fetchConsultationHistory() {
        consultationsReference.orderByChild("senderName").equalTo(patientName)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    historyContainer.removeAllViews() // Clear previous history

                    for (consultationSnapshot in snapshot.children) {
                        val consultation = consultationSnapshot.value as? Map<String, Any>
                        if (consultation != null && consultation["senderName"] == patientName) {
                            addConsultationToHistory(
                                consultation["message"] as String,
                                consultation["doctorName"] as String?,
                                consultation["reply"] as String?,
                                (consultation["reviewed"] as Boolean?).toString()
                            )
                        }
                    }

                    if (historyContainer.childCount == 0) {
                        Toast.makeText(requireContext(), "No consultation history found.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

    @SuppressLint("MissingInflatedId")
    private fun addConsultationToHistory(message: String, doctorName: String?, reply: String?, reviewed: String?) {
        val historyView = LayoutInflater.from(context).inflate(R.layout.history_item, historyContainer, false)

        val patientMessageTextView: TextView = historyView.findViewById(R.id.patientMessage)
        val doctorNameTextView: TextView = historyView.findViewById(R.id.doctorName)
        val doctorReplyTextView: TextView = historyView.findViewById(R.id.doctorReply)
        val consultationstatus: TextView = historyView.findViewById(R.id.constatus)
        var status = ""

        patientMessageTextView.text = "You: $message"
        doctorNameTextView.text = "Replied by: ${doctorName ?: "No doctor have viewed your consultation"}"
        doctorReplyTextView.text = "Reply: ${reply ?: "Not replied on yet "}"
        if(reviewed=="false"){
            status = "Unseen"
        }
        else {
            status = "Seen"
        }
        consultationstatus.text = "Status: ${status}"

        historyContainer.addView(historyView)
    }

    private fun retrieveUserInfo(email: String, callback: (String) -> Unit) {
        usersReference.orderByChild("email").equalTo(email)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        for (userSnapshot in snapshot.children) {
                            val name = userSnapshot.child("name").getValue(String::class.java)
                            if (!name.isNullOrEmpty()) {
                                callback(name) // Pass the name to the callback
                                return
                            }
                        }
                        Toast.makeText(requireContext(), "Name not found for the user.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(requireContext(), "User not found.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }
    private fun clearConsultationHistory() {
        if (patientName == null) {
            Toast.makeText(requireContext(), "Patient name not retrieved yet.", Toast.LENGTH_SHORT).show()
            return
        }

        consultationsReference.orderByChild("senderName").equalTo(patientName)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        for (consultationSnapshot in snapshot.children) {
                            val reviewed = consultationSnapshot.child("reviewed").getValue(Boolean::class.java)
                            if (reviewed == true) {
                                consultationSnapshot.ref.removeValue() // Remove the consultation from Firebase
                            }
                        }
                        historyContainer.removeAllViews() // Clear history from the screen
                        Toast.makeText(requireContext(), "Consultation history cleared.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(requireContext(), "No history found to clear.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(requireContext(), "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                }
            })
    }

}