package com.example.netw704

class User(email: String, name: String, age: Int, gender: String, type: String, image: String) {
    val age: Int = age
    val email: String = email
    val gender: String = gender
    val name: String = name
    val type: String = type
    val image:String =""
}
