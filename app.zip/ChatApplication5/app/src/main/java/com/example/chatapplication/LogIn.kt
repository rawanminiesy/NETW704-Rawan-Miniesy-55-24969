package com.example.chatapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.chatapplication.ui.theme.ChatApplicationTheme
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.oAuthCredential
import com.google.firebase.ktx.Firebase

class LogIn : ComponentActivity() {
    private lateinit var edtEmail: EditText
    private lateinit var edtpassword: EditText
    private lateinit var btnLogIn: Button


    private lateinit var mAuth: FirebaseAuth
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log_in)

        mAuth= FirebaseAuth.getInstance()
        edtEmail = findViewById(R.id.edt_email)
        edtpassword = findViewById(R.id.edt_password)
        btnLogIn = findViewById(R.id.edt_login)

        btnLogIn.setOnClickListener {
            val email= edtEmail.text.toString()
            val password= edtpassword.text.toString()


            login(email,password);
        }
    }


    private fun login(email: String, password: String){
        mAuth.signInWithEmailAndPassword(email,password)
            .addOnCompleteListener(this) { task->
                if(task.isSuccessful){
                    val intent = Intent( this@LogIn, MainActivity::class.java)
                    finish()
                    startActivity(intent)

                }else{
                    Toast.makeText( this@LogIn, "User does not exist", Toast.LENGTH_SHORT).show()


                }
            }



    }
        }



