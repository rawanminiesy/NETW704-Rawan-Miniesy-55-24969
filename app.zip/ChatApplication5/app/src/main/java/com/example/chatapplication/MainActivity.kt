package com.example.chatapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.auth.FirebaseAuth

class MainActivity : ComponentActivity() {
    private lateinit var userRecyclerView: RecyclerView
    private lateinit var userList: ArrayList<User>
    private lateinit var adapter: userAdapter
    private lateinit var mAuth: FirebaseAuth
    private lateinit var btnmap: Button
    private lateinit var button: Button
    private lateinit var logout: Button



    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnmap = findViewById(R.id.map_button)
        button = findViewById(R.id.prof)
        logout=findViewById(R.id.out)
        mAuth= FirebaseAuth.getInstance()
        //userList=ArrayList()
        //adapter= userAdapter( this,userList)

        btnmap.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }
        button.setOnClickListener {
            val intent = Intent(this, profilio::class.java)
            startActivity(intent)
        }
        logout.setOnClickListener {
            val intent = Intent(this, Registerpage::class.java)
            startActivity(intent)
        }
    }


}


